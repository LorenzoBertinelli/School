#include <iostream>

using namespace std;

char car(int num)

int main()
{
    char car;
    int num;
    cout << "Inserisci un carattere: " << endl;
    cin>>car;
    cout << "Inserisci : " << endl;
    cin>>num;


    return 0;
}
