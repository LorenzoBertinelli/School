#include <iostream>
//dati input: raggio
//dati output: area e circonferenza
//vincoli integrit�: raggio>0


double area(double r){
    double area=(r)*(r)*(3.14);
    double circonferenza=(2)*(3.14)*(r);
    return circonferenza;
    return area;
}


using namespace std;

int main()
{
    double r;
    cout << "insrisci il raggio del cerchio: " << endl;
    cin>>r;

    cout << "l'area del cerchio e': " <<area(r) <<endl;
    cout << "la circonferenza del cerchio e': " <<circonferenza(r)<< endl;


    return 0;
}
