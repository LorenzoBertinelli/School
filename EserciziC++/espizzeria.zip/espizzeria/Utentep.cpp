#include <string>
using namespace std;

class utente{
    private: 
    string nome,cognome,email, via;

    public:
    utente();
    utente(string, string, string, string);


    string getnome();
    string getcognome();
    string getemail();
    string getvia();

    void setnome(string);
    void setcognome(string);
    void setemail(string);
    void setvia(string);

};