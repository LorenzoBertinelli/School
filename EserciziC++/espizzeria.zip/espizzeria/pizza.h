#include <string>
using namespace std;
class pizza{
    private:
    string nome;
    string ingredienti;
    float prezzo;

    public:
    pizza();
    pizza(string, string, float);



    string getnome();
    string getingredienti();
    float getprezzo();
    
    void setnome(string);
    void setingredienti(string);
    void setprezzo(float);
};