#include "pizza.h"

pizza::pizza(){

    nome="";
    ingredienti="";
    prezzo=0.0;
}

pizza::pizza(string n, string i, float p){

    nome=n;
    ingredienti=i;
    prezzo=p;
}

string utente::getnome()
{
    return nome;
}
string utente::getingredienti()
{
    return ingredienti;
}
float utente::getprezzo()
{
    return prezzo;
}

void utente::setingredienti(string i)
{
    ingredienti=i;
}
void utente::setemail(string e)
{
    email=e;
}
void utente::setprezzo(float p)
{
    prezzo =p;
}
