#include "utente.h"

utente::utente(){
    nome="";
    cognome="";
    email="";
    via="";
}

utente::utente(string n, string c, string e, string v){

    nome=n;
    cognome=c;
    email=e;
    via=v;

}

string utente::getnome(){

    return this->nome

}
string utente::getcognome(){
    return this->cognome
}

string untente::getemail(){

    return this->email;
}
string untente::getvia(){

    return this->via;
}
void utente::setnome(string n){
nome=n;
}

void utente::setcognome(string c){
cognome = c;
}

void utente::setvia(string v){
    via= v;
    }

void utente::setemail(string e){
        email=e;
}    