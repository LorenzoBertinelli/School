/*

dati input: costo, tipoprodotto
dati output: sconto
vincoli intergrit�: costo>0 e tipoprodotto alimentare o non alimentare*/

#include <iostream>

using namespace std;

int main()
{
    int costo, sconto;
    float tipoprodotto;

    cout << "Inserisci il prodotto (alimentare o non alimentare): " << endl;
    cin>>tipoprodotto;
    cout << "Inserisci il costo: " << endl;
    cin>>costo;

    if(costo>50 && tipoprodotto=non alimentare)
        sconto=costo*30/100;
    else if(tipoprodotto==alimentare){
        sconto=costo*15/100;
    }

    cout<<"Lo sconto e' di: "<<sconto<<endl;

    return 0;
}
