/*
dati input: N
dati output: maggiore dei numeri, media dei numeri e radice quadrata del prodotto ottenuto tra tutti i numeri
vincoli di integrit�: non vi sono*/
#include <iostream>
#include <cmath>


using namespace std;

int main()
{
    float N, maggiore, media, radice, prodotto;
    int i, N2, N3;

    cout<<"Inserisci per quante volte inserire i numeri: "<<endl;
    cin>>N2;



    while(i<=N){
        cout<<"Inserisci il numero: "<<endl;
        cin>>N;
        N3=N;
         if(N3>N){
            maggiore=N3;

        }
        else{
            maggiore=N;
        }
        media=N3+N/2;
        prodotto=N3*N;
        radice=sqrt(prodotto);



    }
    cout<<"Il numero maggiore e': "<<maggiore<<endl;
    cout<<"La media e': "<<media<<endl;
    cout<<"La radice e': "<<radice<<endl;


    return 0;
}
