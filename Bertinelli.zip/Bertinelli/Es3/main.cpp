#include <iostream>

using namespace std;

int main()
{
    int n_valori,somma, V;

    n_valori=0;
    somma=0;

    cout << "Inserisci il valore: " << endl;
    cin>>V;

    do{
        n_valori=n_valori+1;
        V=V-1;
        somma=somma+V;

    }
    while(V!=0);


    cout<<"ci volgiono: "<<n_valori <<" finche valore sia uguale a 0"<<endl;
    cout<<somma<<endl;
    return 0;
}
